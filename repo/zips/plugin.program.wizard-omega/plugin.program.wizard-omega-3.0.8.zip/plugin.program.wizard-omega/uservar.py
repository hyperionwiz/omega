import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://filedn.com/l0jm1ttNAy54e9NylPPsPVk/Omega/text/builds.xml'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'https://filedn.com/l0jm1ttNAy54e9NylPPsPVk/Omega/text/notify/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
