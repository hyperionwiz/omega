# -*- coding: utf-8 -*-
# TRUMP - UNFIT FOR OFFICE
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import os
from urllib.parse import urlencode, unquote

def addon_themes():
	return [{'name': 'Light', 'value': ('FF434343', 'FF2E2E2E'), 'icon': 'light'}, {'name': 'Medium', 'value': ('FF373737', 'FF4a4347'), 'icon': 'medium'},
			{'name': 'Dark', 'value': ('FF1F2020', 'FF4F4F4F'), 'icon': 'dark'}]

def addon_themes_opacity():
	return [{'name': '100%', 'value': 'FF'}, {'name': '95%', 'value': 'F2'}, {'name': '90%', 'value': 'E6'}, {'name': '85%', 'value': 'D9'}, {'name': '80%', 'value': 'CC'},
			{'name': '75%', 'value': 'BF'}, {'name': '70%', 'value': 'B3'}, {'name': '65%', 'value': 'A6'}, {'name': '60%', 'value': '99'}, {'name': '55%', 'value': '8C'},
			{'name': '50%', 'value': '80'}]

def random_valid_type_check():
	return {'build_movie_list': 'movie', 'build_tvshow_list': 'tvshow', 'build_season_list': 'season', 'build_episode_list': 'episode',
	'build_in_progress_episode': 'single_episode', 'build_recently_watched_episode': 'single_episode', 'build_next_episode': 'single_episode',
	'build_my_calendar': 'single_episode', 'build_trakt_lists': 'trakt_list',
	'trakt.list.build_trakt_list': 'trakt_list', 'build_trakt_lists_contents': 'trakt_list', 'personal_lists.build_personal_list': 'personal_list',
	'build_personal_lists_contents': 'personal_list', 'tmdblist.build_tmdb_list': 'tmdb_list', 'build_tmdb_lists_contents': 'tmdb_list'}

def random_episodes_check():
	return {'build_in_progress_episode': 'episode.progress', 'build_recently_watched_episode': 'episode.recently_watched',
	'build_next_episode': 'episode.next', 'build_my_calendar': 'episode.trakt'}

def extras_button_label_values():
	return {'movie':
				{'movies_play': 'Play', 'show_trailers': 'Trailer', 'show_images': 'Images',  'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'show_director': 'Director', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_related': 'Related', 'show_more_like_this': 'More Like This',
				'show_similar': 'Similar', 'show_reviews': 'Reviews', 'show_comments': 'Comments', 'show_trivia': 'Trivia', 'show_blunders': 'Blunders',
				'show_year': 'More Year', 'show_genre': 'More Genres', 'show_network': 'More Network',
				'show_mdblist_manager': 'MDBList', 'show_simkl_manager': 'Simkl Lists', 'show_trakt_manager': 'Trakt Lists', 'show_tmdb_manager': 'TMDb Lists', 'show_personallists_manager': 'Personal Lists',
				'show_favorites_manager': 'Favorites Lists', 'playback_choice': 'Play Options', 'show_plot': 'Plot', 'show_keywords': 'Keywords',
				'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close'},
			'tvshow':
				{'tvshow_browse': 'Browse', 'show_trailers': 'Trailer', 'show_images': 'Images', 'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'play_nextep': 'Play Next', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_related': 'Related', 'show_more_like_this': 'More Like This',
				'show_similar': 'Similar', 'show_reviews': 'Reviews', 'show_comments': 'Comments', 'show_trivia': 'Trivia', 'show_blunders': 'Blunders',
				'show_year': 'More Year', 'show_genre': 'More Genres', 'show_network': 'More Network',
				'show_mdblist_manager': 'MDBList', 'show_simkl_manager': 'Simkl Lists', 'show_trakt_manager': 'Trakt Lists', 'show_tmdb_manager': 'TMDb Lists', 'show_personallists_manager': 'Personal Lists',
				'show_favorites_manager': 'Favorites Lists', 'play_random_episode': 'Play Random', 'show_plot': 'Plot', 'show_keywords': 'Keywords',
				'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close'}}

def extras_items():
	return [{'name': 'Plot', 'value': 2050}, {'name': 'Cast', 'value': 2051}, {'name': 'Recommended', 'value': 2052}, {'name': 'Related', 'value': 2053},
	{'name': 'More Like This', 'value': 2054}, {'name': 'Similar', 'value': 2055}, {'name': 'Reviews', 'value': 2056}, {'name': 'Comments', 'value': 2057},
	{'name': 'Trivia', 'value': 2058}, {'name': 'Blunders', 'value': 2059}, {'name': 'Parental Guide', 'value': 2060}, {'name': 'In Trakt Lists', 'value': 2061},
	{'name': 'Videos', 'value': 2062}, {'name': 'More from Year', 'value': 2063}, {'name': 'More from Genres', 'value': 2064}, {'name': 'More from Networks', 'value': 2065},
	{'name': 'More from Collection', 'value': 2066}]

def context_menu_items():
	return [
	{'name': 'Extras', 'value': 'extras'}, {'name': 'Options', 'value': 'options'}, {'name': 'Play Options', 'value': 'playback_options'},
	{'name': 'Select Source', 'value': 'select_source'}, {'name': 'Rescrape & Select Source', 'value': 'rescrape_select_source'},
	{'name': 'External Scraper Settings', 'value': 'external_scraper_settings'},
	{'name': 'Browse Movie Set', 'value': 'browse_movie_set'}, {'name': 'Browse TV Seasons', 'value': 'browse_seasons'},
	{'name': 'Browse Season Episodes', 'value': 'browse_episodes'}, {'name': 'Browse Recommended', 'value': 'recommended'}, {'name': 'Browse Related', 'value': 'related'},
	{'name': 'Browse More Like This', 'value': 'more_like_this'}, {'name': 'Browse Similar', 'value': 'similar'}, {'name': 'In Trakt Lists', 'value': 'in_trakt_list'},
	{'name': 'MDBList Manager', 'value': 'mdblist_manager'}, {'name': 'MDBList Watchlist', 'value': 'mdblist_watchlist'}, {'name': 'MDBList Library', 'value': 'mdblist_library'},
	{'name': 'Simkl Lists Manager', 'value': 'simkl_manager'}, {'name': 'Simkl Plan to Watch', 'value': 'simkl_plantowatch'},
	{'name': 'Trakt Lists Manager', 'value': 'trakt_manager'}, {'name': 'Trakt Watchlist', 'value': 'trakt_watchlist'}, {'name': 'Trakt Collection', 'value': 'trakt_collection'},
	{'name': 'TMDb Lists Manager', 'value': 'tmdb_manager'}, {'name': 'TMDb Watchlist', 'value': 'tmdb_watchlist'}, {'name': 'TMDb Favorites', 'value': 'tmdb_favorites'},
	{'name': 'Personal Lists Manager', 'value': 'personal_manager'}, {'name': 'Favorites Manager', 'value': 'favorites_manager'}, {'name': 'Mark Watched/Unwatched', 'value': 'mark_watched'},
	{'name': 'Unmark Previous Watched Episode', 'value': 'unmark_previous_episode'}, {'name': 'Exit List', 'value': 'exit'}, {'name': 'Refresh Widgets', 'value': 'refresh'},
	{'name': 'Reload Widgets', 'value': 'reload'}]

def rescrape_items():
	return [
	{'name': 'Rescrape With No Cache Check', 'value': 'cache_ignored'},
	{'name': 'Rescrape With IMDb Year Data', 'value': 'imdb_year'},
	{'name': 'Rescrape With Disabled External Providers', 'value': 'with_all'},
	{'name': 'Rescrape With Episode Group', 'value': 'episode_group'},
	{'name': 'Rescrape with Filters Ignored', 'value': 'ignore_filters'},
	{'name': 'Offer Full Search After Early Results', 'value': 'full_scrape'}]

def video_extensions():
	return ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
			'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
			'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
			'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')

def image_extensions():
	return ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
			'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')

def kodi_progress_background():
	return xbmcgui.DialogProgressBG()

def get_visibility(obj):
	return xbmc.getCondVisibility(obj)

def get_infolabel(label):
	return xbmc.getInfoLabel(label)

def kodi_actor():
	return xbmc.Actor

def translate_path(_path):
	return xbmcvfs.translatePath(_path)

def kodi_monitor():
	return xbmc.Monitor()

def kodi_player():
	return xbmc.Player()

def playback_is_paused():
	try:
		if get_visibility('Player.Paused'):
			return True
	except:
		pass
	try:
		player = kodi_player()
		if not (player.isPlayingVideo() or player.isPlaying()):
			return False
		props = get_jsonrpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties', 'params': {'playerid': 1, 'properties': ['speed']}})
		if props is not None and float(props.get('speed', 1)) == 0.0:
			return True
	except:
		pass
	return False

def kodi_dialog():
	return xbmcgui.Dialog()

def is_android():
	return get_visibility('System.Platform.Android')

def _folder_has_entries(path):
	try:
		tpath = translate_path(path)
		if not path_exists(tpath) or not os.path.isdir(tpath):
			return False
		with os.scandir(tpath) as scan:
			return any(True for _ in scan)
	except:
		return False

def safe_browse_defaultt(path):
	# Kodi on Android can block parent navigation when browse opens inside a non-empty folder.
	if not is_android() or not path or path in ('None', ''):
		return path
	if _folder_has_entries(path):
		return ''
	return path

def browse_start_path(path, force_defaultt=False):
	'''Native folder path for Kodi browse defaultt (address bar shows the real location).'''
	if not path or str(path).strip() in ('', 'None', 'empty_setting'):
		return None
	native = translate_path(path)
	if not native or not str(native).strip():
		return None
	if force_defaultt:
		# Import/export defaults use special:// paths; Kodi browse accepts them on all platforms.
		if str(path).strip().lower().startswith('special://'):
			return path
		return native
	start = safe_browse_defaultt(native)
	if start == '':
		return ''
	return start if start else None

def _browse_paths_equal(a, b):
	if not a or not b:
		return False
	try:
		return os.path.normpath(translate_path(a)) == os.path.normpath(translate_path(b))
	except:
		return a == b

def browse_directory(defaultt='', heading='Choose folder', use_defaultt=False, confirm_unchanged=False, force_defaultt=False):
	# Kodi returns defaultt unchanged when the user cancels (same as pressing OK without moving).
	start = browse_start_path(defaultt, force_defaultt=force_defaultt) if use_defaultt else None
	result = kodi_dialog().browse(0, heading, '', defaultt=start)
	if not result or not str(result).strip():
		return None
	if start is not None and _browse_paths_equal(result, start):
		if confirm_unchanged:
			display = result if len(result) <= 120 else '%s...' % result[:117]
			if not confirm_dialog(
				heading=heading,
				text='Use this folder?[CR][CR][B]%s[/B]' % display,
				ok_label='Continue',
				cancel_label='Cancel',
				default_control=10,
			):
				return None
		else:
			return None
	return result

def browse_file(mask='', defaultt='', heading='Choose file', force_defaultt=False):
	# File browse: cancel with a folder defaultt returns that path, not an empty string.
	start = browse_start_path(defaultt, force_defaultt=force_defaultt)
	result = kodi_dialog().browse(1, heading, '', mask, defaultt=start)
	if not result or not str(result).strip():
		return None
	if start is not None and _browse_paths_equal(result, start) and not os.path.isfile(translate_path(result)):
		return None
	return result

def addon_info(info):
	return xbmcaddon.Addon('plugin.video.mando').getAddonInfo(info)

def addon_version():
	return get_property('mando.addon_version') or addon_info('version')

def addon_path():
	return get_property('mando.addon_path') or addon_info('path')

def addon_profile():
	try:
		return translate_path(addon_info('profile'))
	except:
		return get_property('mando.addon_profile') or ''

def addon_icon():
	return get_property('mando.addon_icon') or translate_path(addon_info('icon'))

def addon_icon_mini():
	return get_property('mando.addon_icon_mini') or os.path.join(addon_info('path'), 'resources', 'media', 'addon_icons', 'minis',
														os.path.basename(translate_path(addon_info('icon'))))

def addon_fanart():
	return (
		get_property('mando.addon_fanart')
		or 'special://home/addons/plugin.video.mando/resources/media/fanart.jpg'
	)

MEDIA_GITHUB_USER = 'kodiwind'
MEDIA_GITHUB_REPO = 'proximus'
MEDIA_GITHUB_RAW = 'https://raw.githubusercontent.com/%s/%s/main/packages/media' % (MEDIA_GITHUB_USER, MEDIA_GITHUB_REPO)
LEGACY_MEDIA_GITHUB_RAW = 'https://raw.githubusercontent.com/kodiwind/proximus.github.io/main/packages/media'
# Estuary WideList row icons use ListItem.Icon only for Container.Content() — not files.
MENU_FOLDER_CONTENT = ''

def media_github_credentials():
	return MEDIA_GITHUB_USER, MEDIA_GITHUB_REPO

def get_icon(image_name, image_folder='icons', image_type='png'):
	local_path = os.path.join(addon_info('path'), 'resources', 'media', image_folder, '%s.%s' % (image_name, image_type))
	if os.path.exists(local_path):
		return local_path
	return '%s/%s/%s.%s' % (MEDIA_GITHUB_RAW, image_folder, image_name, image_type)

def resolve_list_icon(icon, default_name='folder'):
	if not icon:
		return get_icon(default_name)
	if icon.startswith('http'):
		if icon.startswith(LEGACY_MEDIA_GITHUB_RAW):
			return MEDIA_GITHUB_RAW + icon[len(LEGACY_MEDIA_GITHUB_RAW):]
		return icon
	icon_norm = icon.replace('\\', '/')
	if icon_norm.startswith('special://') or 'plugin.video.mando/resources/media/' in icon_norm:
		for folder in ('icons', 'flags', 'network_icons', 'results', 'rpdb_posters', 'themes'):
			if '/%s/' % folder in icon_norm:
				name = os.path.splitext(os.path.basename(icon_norm))[0]
				ext = os.path.splitext(icon_norm)[1].lstrip('.') or 'png'
				return get_icon(name, folder, ext)
		return get_icon(os.path.splitext(os.path.basename(icon_norm))[0])
	return get_icon(icon)

def set_list_item_art(listitem, icon, fanart=None, banner=None, landscape=None):
	art = {'icon': icon, 'poster': icon, 'thumb': icon, 'banner': banner or icon, 'landscape': landscape or icon}
	if fanart: art['fanart'] = fanart
	listitem.setArt(art)
	try: listitem.setIconImage(icon) # Estuary WideList reads ListItem.Icon, not Art(thumb).
	except: pass

def get_addon_fanart():
	return get_property('mando.default_addon_fanart') or addon_fanart()

def build_url(url_params):
	return 'plugin://plugin.video.mando/?%s' % urlencode(url_params)

# Keep `random` / `shuffle` on folder URLs — stripping `random` broke Random Trakt Public (All)
# and any other list-of-lists parent that only passed random=true (shuffle alone was the workaround).
_FOLDER_URL_SKIP = frozenset(('iconImage', 'random_support', 'name', 'isFolder'))
_FOLDER_URL_KEEP_NAME_MODES = frozenset(('navigator.build_shortcut_folder_contents',))

def _folder_url_keep_name(mode):
	if mode in _FOLDER_URL_KEEP_NAME_MODES: return True
	return mode.startswith('random.build_')

def build_folder_url(url_params):
	mode = url_params.get('mode', '')
	skip = _FOLDER_URL_SKIP
	if _folder_url_keep_name(mode):
		skip = skip - frozenset(('name',))
	routing = {k: v for k, v in url_params.items() if k not in skip and v not in (None, '')}
	if 'category_name' not in routing and url_params.get('name') and mode in ('build_movie_list', 'build_tvshow_list'):
		routing['category_name'] = url_params['name']
	return build_url(routing)

def sanitize_folder_url(url):
	if not url or 'plugin.video.mando' not in url: return url
	try:
		from urllib.parse import parse_qsl, unquote
		query = unquote(url.split('?', 1)[-1])
		params = dict(parse_qsl(query, keep_blank_values=True))
		return build_folder_url(params)
	except: return url

def set_browse_exit_params(list_mode='tvshow', action=None):
	if external(): return
	set_property('mando.exit_params', browse_list_exit_params(list_mode, action))

def browse_list_exit_params(list_mode='tvshow', action=None):
	folder_path = get_infolabel('Container.FolderPath')
	parent_tokens = ('navigator.', 'mdblist.', 'simkl.', 'trakt.list', 'tmdblist.', 'personal_lists.', 'build_tmdb_lists_contents')
	if any(token in folder_path for token in parent_tokens):
		return sanitize_folder_url(folder_path)
	if action:
		action_parent = _browse_action_exit_params.get(action)
		if action_parent: return build_folder_url(action_parent)
		subnav_parent = _browse_subnav_exit_params.get(action)
		if subnav_parent: return build_folder_url(subnav_parent)
	build_mode = 'build_movie_list' if list_mode == 'movie' else 'build_tvshow_list'
	if build_mode in folder_path:
		nav_actions = {'movie': 'MovieList', 'tvshow': 'TVShowList', 'anime': 'AnimeList'}
		return build_folder_url({'mode': 'navigator.main', 'action': nav_actions.get(list_mode, 'TVShowList')})
	return sanitize_folder_url(folder_path)

def list_collection_exit_params(params=None):
	folder_path = get_infolabel('Container.FolderPath')
	parent_tokens = (
		'trakt.list.get_trakt_lists', 'trakt.list.search_trakt', 'trakt.list.get_trakt_user_lists',
		'tmdblist.get_tmdb_lists', 'personal_lists.get_personal_lists', 'navigator.', 'mdblist.', 'simkl.')
	if any(token in folder_path for token in parent_tokens):
		return sanitize_folder_url(folder_path)
	params = params or {}
	mode = params.get('mode', '')
	if mode in ('trakt.list.build_trakt_list', 'random.build_trakt_lists_contents'):
		return build_folder_url({'mode': 'trakt.list.get_trakt_lists', 'list_type': params.get('list_type', 'my_lists')})
	if mode in ('tmdblist.build_tmdb_list', 'random.build_tmdb_lists_contents'):
		return build_folder_url({'mode': 'tmdblist.get_tmdb_lists'})
	if mode in ('personal_lists.build_personal_list', 'random.build_personal_lists_contents'):
		return build_folder_url({'mode': 'personal_lists.get_personal_lists'})
	return sanitize_folder_url(folder_path)

_browse_action_exit_params = {
	'mdblist_watchlist': {'mode': 'navigator.mdblist_lists'},
	'mdblist_collection': {'mode': 'navigator.mdblist_lists'},
	'mdblist_droplist': {'mode': 'navigator.mdblist_lists'},
	'trakt_collection': {'mode': 'navigator.trakt_collections'},
	'trakt_collection_lists': {'mode': 'navigator.trakt_collections'},
	'trakt_watchlist': {'mode': 'navigator.trakt_watchlists'},
	'trakt_watchlist_lists': {'mode': 'navigator.trakt_watchlists'},
	'trakt_favorites': {'mode': 'navigator.trakt_favorites', 'category_name': 'Favorites'},
	'trakt_recommendations': {'mode': 'navigator.trakt_recommendations', 'category_name': 'Recommended'},
	'simkl_plantowatch': {'mode': 'navigator.simkl_lists'},
	'simkl_completed': {'mode': 'navigator.simkl_lists'},
	'simkl_watching': {'mode': 'navigator.simkl_lists'},
	'simkl_hold': {'mode': 'navigator.simkl_lists'},
	'simkl_dropped': {'mode': 'navigator.simkl_lists'},
	'favorites_movies': {'mode': 'navigator.favorites'},
	'favorites_tvshows': {'mode': 'navigator.favorites'},
	'favorites_anime': {'mode': 'navigator.favorites'},
}

_browse_subnav_exit_params = {
	'tmdb_movies_genres': {'mode': 'navigator.genres', 'menu_type': 'movie'},
	'tmdb_tv_genres': {'mode': 'navigator.genres', 'menu_type': 'tvshow'},
	'tmdb_anime_genres': {'mode': 'navigator.genres', 'menu_type': 'anime'},
	'tmdb_movies_providers': {'mode': 'navigator.providers', 'menu_type': 'movie'},
	'tmdb_tv_providers': {'mode': 'navigator.providers', 'menu_type': 'tvshow'},
	'tmdb_anime_providers': {'mode': 'navigator.providers', 'menu_type': 'anime'},
	'tmdb_movies_languages': {'mode': 'navigator.languages', 'menu_type': 'movie'},
	'tmdb_tv_languages': {'mode': 'navigator.languages', 'menu_type': 'tvshow'},
	'tmdb_movies_year': {'mode': 'navigator.years', 'menu_type': 'movie'},
	'tmdb_tv_year': {'mode': 'navigator.years', 'menu_type': 'tvshow'},
	'tmdb_anime_year': {'mode': 'navigator.years', 'menu_type': 'anime'},
	'tmdb_movies_decade': {'mode': 'navigator.decades', 'menu_type': 'movie'},
	'tmdb_tv_decade': {'mode': 'navigator.decades', 'menu_type': 'tvshow'},
	'tmdb_anime_decade': {'mode': 'navigator.decades', 'menu_type': 'anime'},
	'tmdb_movies_certifications': {'mode': 'navigator.certifications', 'menu_type': 'movie'},
	'trakt_tv_certifications': {'mode': 'navigator.certifications', 'menu_type': 'tvshow'},
	'trakt_anime_certifications': {'mode': 'navigator.certifications', 'menu_type': 'anime'},
	'tmdb_tv_networks': {'mode': 'navigator.networks', 'menu_type': 'tvshow'},
	'tmdb_movies_discover': {'mode': 'navigator.discover_contents', 'media_type': 'movie'},
	'tmdb_tv_discover': {'mode': 'navigator.discover_contents', 'media_type': 'tvshow'},
}

def add_dir(handle, url_params, list_name, icon_image='folder', fanart_image=None, isFolder=True):
	fanart = fanart_image or get_addon_fanart()
	icon = get_icon(icon_image)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	set_list_item_art(listitem, icon, fanart=fanart, banner=fanart)
	info_tag = listitem.getVideoInfoTag(True)
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def make_listitem(offscreen=True):
	return xbmcgui.ListItem(offscreen=offscreen)

def add_item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	xbmcplugin.addDirectoryItems(handle, item_list)

def set_content(handle, content):
	xbmcplugin.setContent(handle, content)

def set_category(handle, label):
	xbmcplugin.setPluginCategory(handle, label)

def end_directory(handle, updateListing=False, cacheToDisc=True):
	xbmcplugin.endOfDirectory(handle, updateListing=updateListing, cacheToDisc=cacheToDisc)

# Estuary List (50) is for movies/tvshows content only — not plugin browse folders.
_ESTUARY_MENU_VIEW_MAP = {'50': '55'}

def _view_schema_default(view_type):
	try:
		from caches.settings_cache import default_setting_values
		schema = default_setting_values(view_type.replace('mando.', ''))
		if schema: return str(schema.get('setting_default', '')).strip()
	except: pass
	return ''

def _resolve_view_id(view_type, fallback_view_types=()):
	view_id = None
	try:
		from caches.settings_cache import get_setting, ensure_settings_properties_loaded
		ensure_settings_properties_loaded()
		view_id = get_property('mando.%s' % view_type) or get_setting('mando.%s' % view_type) or get_setting(view_type)
	except: view_id = None
	if not view_id: return None
	view_id = str(view_id).strip()
	if view_type == 'view.main' and 'estuary' in (current_skin() or '').lower():
		view_id = _ESTUARY_MENU_VIEW_MAP.get(view_id, view_id)
	if fallback_view_types:
		primary_default = _view_schema_default(view_type)
		if primary_default and str(view_id) == primary_default:
			for fallback_type in fallback_view_types:
				fallback_id = _resolve_view_id(fallback_type)
				if not fallback_id: continue
				fallback_default = _view_schema_default(fallback_type)
				if str(fallback_id) != str(fallback_default):
					return fallback_id
	return view_id

def set_view_mode(view_type, content='files', is_external=None, fallback_view_types=()):
	if get_property('mando.use_viewtypes') != 'true': return
	if is_external == None: is_external = external()
	if is_external: return
	view_id = _resolve_view_id(view_type, fallback_view_types)
	if not view_id: return
	if content is None: content = 'files'
	try:
		sleep(100)
		for _ in range(3000):
			if container_content() != content:
				sleep(1)
				continue
			current = get_infolabel('Container.Viewmode.id') or get_infolabel('Container.Viewmode')
			if current and str(current) == str(view_id): return
			execute_builtin('Container.SetViewMode(%s)' % view_id)
			return
	except: return

def random_integer(start=1, end=1000000):
	from random import randint
	return randint(start, end)

def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item

def append_path(_path):
	import sys
	sys.path.append(translate_path(_path))

def logger(heading, function):
	xbmc.log('###%s###: %s' % (heading, function), 1)

def kodi_window():
	return xbmcgui.Window(10000)

def get_property(prop):
	return kodi_window().getProperty(prop)

def set_property(prop, value):
	return kodi_window().setProperty(prop, value)

def clear_property(prop):
	return kodi_window().clearProperty(prop)

def sync_scrape_progress_ui(percent=0, results_sd=0, results_720p=0, results_1080p=0, results_4k=0, results_total=0):
	from caches.settings_cache import get_setting
	set_property('mando.scrape.percent', str(int(percent)))
	set_property('mando.scrape.results_sd', str(results_sd))
	set_property('mando.scrape.results_720p', str(results_720p))
	set_property('mando.scrape.results_1080p', str(results_1080p))
	set_property('mando.scrape.results_4k', str(results_4k))
	set_property('mando.scrape.results_total', str(results_total))
	if get_setting('mando.highlight.scrape_progress_colours', 'true') == 'true':
		set_property('mando.scrape.progress_4k_color', get_setting('mando.scraper_4k_highlight', 'FFFF00FE'))
		set_property('mando.scrape.progress_1080p_color', get_setting('mando.scraper_1080p_highlight', 'FFE6B800'))
		set_property('mando.scrape.progress_720p_color', get_setting('mando.scraper_720p_highlight', 'FF3C9900'))
		set_property('mando.scrape.progress_sd_color', get_setting('mando.scraper_SD_highlight', 'FF0166FF'))
		set_property('mando.scrape.progress_total_color', get_setting('mando.scraper_total_highlight', 'FFFFFFFF'))
	else:
		white = 'FFFFFFFF'
		set_property('mando.scrape.progress_4k_color', white)
		set_property('mando.scrape.progress_1080p_color', white)
		set_property('mando.scrape.progress_720p_color', white)
		set_property('mando.scrape.progress_sd_color', white)
		set_property('mando.scrape.progress_total_color', white)

def clear_scrape_progress_ui():
	for prop in ('mando.scrape.percent', 'mando.scrape.results_sd', 'mando.scrape.results_720p',
			'mando.scrape.results_1080p', 'mando.scrape.results_4k', 'mando.scrape.results_total',
			'mando.scrape.progress_4k_color', 'mando.scrape.progress_1080p_color',
			'mando.scrape.progress_720p_color', 'mando.scrape.progress_sd_color',
			'mando.scrape.progress_total_color',
			'mando.scrape.ready'):
		clear_property(prop)

def clear_all_properties():
	return kodi_window().clearProperties()

def addon(addon_id='plugin.video.mando'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility('System.HasAddon(%s)' % addon_id)

def addon_enabled(addon_id):
	return get_visibility('System.AddonIsEnabled(%s)' % addon_id)

def service_scrobbler_defer(addon_id, auth_keys=(), scrobble_enable_keys=()):
	"""Return True when an external service addon should own playback scrobbling."""
	if not addon_installed(addon_id) or not addon_enabled(addon_id): return False
	try: inst = addon(addon_id)
	except: return False
	if auth_keys:
		authed = False
		for key in auth_keys:
			try:
				val = str(inst.getSetting(key) or '').strip()
				if val and val not in ('empty_setting',): authed = True; break
			except: pass
		if not authed: return False
	for key in scrobble_enable_keys:
		try:
			val = str(inst.getSetting(key) or '').strip().lower()
			if val in ('false', '0', 'no', 'off'): return False
			if val in ('true', '1', 'yes', 'on'): return True
		except: pass
	return bool(auth_keys)

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	xbmcplugin.addSortMethod(handle, {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}[method])

def make_session(url='https://'):
	import requests
	session = requests.Session()
	session.mount(url, requests.adapters.HTTPAdapter(pool_maxsize=100))
	return session	

def make_playlist(playlist_type='video'):
	return xbmc.PlayList({'music': 0, 'video': 1}[playlist_type])

def clear_video_playlist():
	'''Drop episode plugin URLs left on the video playlist when browse/direct play starts during a scrape.'''
	try:
		make_playlist('video').clear()
	except:
		try:
			execute_builtin('Playlist.Clear')
		except:
			pass

def supported_media():
	return xbmc.getSupportedMedia('video')

def path_exists(path):
	return xbmcvfs.exists(path)

def open_file(_file, mode='r'):
	return xbmcvfs.File(_file, mode)

def copy_file(source, destination):
	return xbmcvfs.copy(source, destination)

def delete_file(_file):
	xbmcvfs.delete(_file)

def delete_folder(_folder, force=False):
	xbmcvfs.rmdir(_folder, force)

def rename_file(old, new):
	xbmcvfs.rename(old, new)

def list_dirs(location):
	return xbmcvfs.listdir(location)

def make_directory(path):
	xbmcvfs.mkdir(path)

def make_directories(path):
	xbmcvfs.mkdirs(path)

def sleep(time):
	return xbmc.sleep(time)

def execute_builtin(command, block=False):
	return xbmc.executebuiltin(command, block)

def current_skin():
	return xbmc.getSkinDir()

def get_window_id():
	return xbmcgui.getCurrentWindowId()

def current_window_object():
	return xbmcgui.Window(get_window_id())

def kodi_version():
	return int(get_infolabel('System.BuildVersion')[0:2])

def get_video_database_path():
	return translate_path('special://profile/Database/MyVideos%s.db' % {19: '119', 20: '121', 21: '124'}[kodi_version()])

def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog():
	execute_builtin('Dialog.Close(busydialognocancel)')
	execute_builtin('Dialog.Close(busydialog)')

def close_dialog(dialog, block=False):
	execute_builtin('Dialog.Close(%s,true)' % dialog, block)

def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.mando', block=False):
	return execute_builtin('RunAddon(%s)' % addon, block)

def external():
	return 'mando' not in get_infolabel('Container.PluginName')

def home():
	return xbmcgui.getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in unquote(folder_path())

def reload_skin():
	execute_builtin('ReloadSkin()')

def kodi_refresh():
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

SHUTTING_DOWN_PROP = 'mando.shutting_down'
PROP_AUTOSCRAPE_TOAST_SHOWN = 'mando.autoscrape_nextep_toast_shown'
PLAYBACK_WIDGET_REFRESH_PROP = 'mando.playback_widget_refresh_at'
PLAYBACK_WIDGET_REFRESH_COOLDOWN_SEC = 120
BOOT_SYNC_STARTED_PROP = 'mando.boot_sync_started_at'
BOOT_TRAKT_SYNC_READY_PROP = 'mando.boot_trakt_sync_ready'
BOOT_SYNC_GATE_TIMEOUT_SEC = 180

def reset_boot_sync_gate():
	try:
		from time import time
		set_property(BOOT_SYNC_STARTED_PROP, str(time()))
	except:
		pass
	clear_property(BOOT_TRAKT_SYNC_READY_PROP)

def mark_boot_trakt_sync_ready():
	set_property(BOOT_TRAKT_SYNC_READY_PROP, 'true')

def boot_trakt_list_refresh_allowed():
	if get_property(BOOT_TRAKT_SYNC_READY_PROP) == 'true':
		return True
	try:
		from time import time
		started = float(get_property(BOOT_SYNC_STARTED_PROP) or 0)
		if started and (time() - started) >= BOOT_SYNC_GATE_TIMEOUT_SEC:
			return True
	except:
		pass
	return False

def service_shutting_down(monitor=None):
	if monitor and monitor.abortRequested(): return True
	return get_property(SHUTTING_DOWN_PROP) == 'true'

def cancel_widget_refresh_alarms():
	try: execute_builtin('CancelAlarm(mando_widget_refresh,silent)')
	except: pass
	try: execute_builtin('CancelAlarm(mando_widget_skin,silent)')
	except: pass

def prepare_service_shutdown():
	set_property(SHUTTING_DOWN_PROP, 'true')
	cancel_widget_refresh_alarms()

def schedule_widget_refresh(silent=True, reload_skin=False):
	if service_shutting_down(): return
	url = 'plugin://plugin.video.mando/?mode=refresh_widgets&silent=%s&reload_skin=%s' % ('true' if silent else 'false', 'true' if reload_skin else 'false')
	execute_builtin('AlarmClock(mando_widget_refresh,RunPlugin(%s),00:00:02,silent)' % url)

def mark_playback_widget_refresh():
	try:
		from time import time
		set_property(PLAYBACK_WIDGET_REFRESH_PROP, str(time()))
	except:
		pass

def playback_widget_refresh_recent():
	try:
		from time import time
		at = float(get_property(PLAYBACK_WIDGET_REFRESH_PROP) or 0)
		return at > 0 and (time() - at) < PLAYBACK_WIDGET_REFRESH_COOLDOWN_SEC
	except:
		return False

def schedule_playback_widget_refresh():
	if service_shutting_down(): return
	mark_playback_widget_refresh()
	schedule_widget_refresh(silent=True)

def refresh_widgets(silent=False, reload_skin=False):
	if service_shutting_down(): return
	from caches.settings_cache import get_setting
	from caches.random_widgets_cache import RandomWidgets
	from caches.lists_cache import lists_cache
	RandomWidgets().delete_like('random_list.%')
	if reload_skin: lists_cache.delete_like('trakt_movies_trending_%')
	kodi_refresh()
	try:
		if home(): container_refresh()
	except: pass
	if reload_skin:
		try: execute_builtin('AlarmClock(mando_widget_skin,ReloadSkin(),00:00:01,silent)')
		except: pass
	if not silent and get_setting('mando.widget_refresh_notification', 'true') == 'true': notification('Widgets Refreshed', 2500)

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('RunPlugin(%s)' % params, block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('Container.Update(%s)' % params, block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('ActivateWindow(Videos,%s,return)' % params, block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('Container.Refresh(%s)' % params, block)

def replace_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('ReplaceWindow(Videos,%s)' % params, block)

def disable_enable_addon(addon_name='plugin.video.mando'):
	import json
	try:
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)

def addon_ui_busy():
	try:
		player = xbmc.Player()
		if player.isPlaying() or player.isPlayingVideo(): return True
	except: pass
	if get_property('mando.window_loaded') == 'true': return True
	try:
		if xbmc.getCondVisibility('Window.IsActive(dialog)'): return True
	except: pass
	return False

def language_invoker_from_addon_xml(addon_name='plugin.video.mando'):
	try:
		from xml.dom.minidom import parse as mdParse
		addon_xml = translate_path('special://home/addons/%s/addon.xml' % addon_name)
		if not path_exists(addon_xml): return 'true'
		root = mdParse(addon_xml)
		tags = root.getElementsByTagName('reuselanguageinvoker')
		if not tags: return 'true'
		node = tags[0].firstChild
		return (node.data or 'true').strip().lower()
	except:
		return 'true'

_ADDON_XML_SYNC_VERSION = 'mando.addon_xml_sync_version'
_ADDON_XML_APPLIED = 'mando.addon_xml_applied'

def addon_xml_sync_needed():
	return get_property(_ADDON_XML_SYNC_VERSION) != addon_info('version')

def mark_addon_xml_synced():
	set_property(_ADDON_XML_SYNC_VERSION, addon_info('version'))

def clear_addon_xml_sync_version():
	clear_property(_ADDON_XML_SYNC_VERSION)

def sync_addon_xml_from_settings(addon_name='plugin.video.mando'):
	from xml.dom.minidom import parse as mdParse
	from caches.settings_cache import get_setting
	addon_xml = translate_path('special://home/addons/%s/addon.xml' % addon_name)
	if not path_exists(addon_xml): return False, False
	invoker_setting = get_setting('mando.reuse_language_invoker', None)
	icon_setting = get_setting('mando.addon_icon_choice', None)
	if invoker_setting is None and icon_setting is None: return False, False
	root = mdParse(addon_xml)
	changed = False
	invoker_changed = False
	if invoker_setting is not None:
		tags = root.getElementsByTagName('reuselanguageinvoker')
		if tags:
			node = tags[0].firstChild
			current = (node.data or '').strip().lower() if node else ''
			target = str(invoker_setting).strip().lower()
			if node and current != target:
				node.data = target
				changed = True
				invoker_changed = True
	if icon_setting is not None:
		tags = root.getElementsByTagName('icon')
		if tags:
			node = tags[0].firstChild
			current = (node.data or '').strip() if node else ''
			target = str(icon_setting).strip()
			if node and current != target:
				node.data = target
				changed = True
	if changed:
		new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
		with open(addon_xml, 'w') as f: f.write(new_xml)
	return changed, invoker_changed

def addon_xml_settings_diff(addon_name='plugin.video.mando'):
	from xml.dom.minidom import parse as mdParse
	from caches.settings_cache import get_setting
	addon_xml = translate_path('special://home/addons/%s/addon.xml' % addon_name)
	invoker_mismatch = icon_mismatch = False
	if not path_exists(addon_xml): return invoker_mismatch, icon_mismatch
	invoker_setting = get_setting('mando.reuse_language_invoker', None)
	icon_setting = get_setting('mando.addon_icon_choice', None)
	root = mdParse(addon_xml)
	if invoker_setting is not None:
		tags = root.getElementsByTagName('reuselanguageinvoker')
		if tags:
			node = tags[0].firstChild
			current = (node.data or '').strip().lower() if node else ''
			target = str(invoker_setting).strip().lower()
			invoker_mismatch = current != target
	if icon_setting is not None:
		tags = root.getElementsByTagName('icon')
		if tags:
			node = tags[0].firstChild
			current = (node.data or '').strip() if node else ''
			target = str(icon_setting).strip()
			icon_mismatch = current != target
	return invoker_mismatch, icon_mismatch

def finish_addon_xml_sync():
	mark_addon_xml_synced()
	set_property(_ADDON_XML_APPLIED, 'true')

def restart_addon_for_addon_xml_change(notify=True):
	if notify:
		notification('Refreshing addon.xml. Restarting Mando.', 8000)
	execute_builtin('ActivateWindow(Home)', True)
	update_local_addons()
	disable_enable_addon()

def reuse_language_invoker_check(force=False):
	"""Fen-style: restore addon.xml from settings; disable/enable when invoker or icon differs."""
	try:
		if not force and get_property(_ADDON_XML_APPLIED) == 'true' and not addon_xml_sync_needed():
			return False
		invoker_mismatch, icon_mismatch = addon_xml_settings_diff()
		if not invoker_mismatch and not icon_mismatch:
			finish_addon_xml_sync()
			return False
		changed, _invoker_changed = sync_addon_xml_from_settings()
		if not changed:
			logger('Mando', 'AddonXMLCheck - addon.xml sync failed')
			return False
		logger('Mando', 'AddonXMLCheck - Change Detected. Restarting Mando')
		finish_addon_xml_sync()
		restart_addon_for_addon_xml_change(notify=not force)
		return True
	except Exception as e:
		logger('reuse_language_invoker_check', str(e))
		return False

def ensure_addon_xml_from_settings(force=False):
	"""Settings import / forced restore only — not used from plugin routing."""
	return reuse_language_invoker_check(force=force)

def update_kodi_addons_db(addon_name='plugin.video.mando'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(translate_path('special://database/Addons33.db'), timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except: pass

def get_jsonrpc(request):
	import json
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try:
		files = get_jsonrpc(command).get('files')
		results = [i for i in files if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results

def jsonrpc_get_addons(_type, properties=['thumbnail', 'name']):
	command = {'jsonrpc': '2.0', 'method': 'Addons.GetAddons','params':{'type':_type, 'properties': properties}, 'id': '1'}
	results = get_jsonrpc(command).get('addons')
	return results

def jsonrpc_get_system_setting(setting_id, setting_value=''):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}}
	try: result = get_jsonrpc(command)['value']
	except: result = setting_value
	return result

def jsonrpc_set_system_setting(setting_id, value):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue', 'params': {'setting': setting_id, 'value': value}}
	try: return get_jsonrpc(command)
	except: return None

def open_settings(section=None):
	try:
		from caches.settings_cache import refresh_settings_manager_properties
		refresh_settings_manager_properties()
	except Exception as e:
		logger('open_settings', 'bootstrap: %s' % e)
	try:
		from apis.aiostreams_api import refresh_settings_properties
		refresh_settings_properties()
	except: pass
	section_indexes = {'torrent': 5, 'direct': 6, '61': 5, '62': 6, 'torrent_sources': 5, 'direct_sources': 6}
	focus_key = str(section or '').strip().lower()
	if focus_key in section_indexes:
		set_property('mando.settings_manager.focus_index', str(section_indexes[focus_key]))
	else:
		clear_property('mando.settings_manager.focus_index')
	from windows.base_window import open_window
	try:
		open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml')
	finally:
		clear_property('mando.settings_manager.focus_index')

def external_scraper_settings(params=None):
	try:
		import json
		from modules import settings
		params = params or {}
		slot = None
		if params.get('slot') not in (None, ''):
			try: slot = int(params.get('slot'))
			except: slot = None
		slots = settings.configured_external_scraper_slots()
		if not slots:
			external = get_property('mando.external_scraper.module')
			if external in ('empty_setting', ''): return
			execute_builtin('Addon.OpenSettings(%s)' % external)
			return
		if slot is None:
			if len(slots) == 1:
				slot = slots[0]['slot']
			else:
				list_items = []
				for entry in slots:
					line2 = 'Slot %d' % entry['slot']
					if not entry['enabled']: line2 = '%s (disabled)' % line2
					list_items.append({'line1': entry['display_name'], 'line2': line2})
				kwargs = {'items': json.dumps(list_items), 'heading': 'External Scraper Settings', 'multi_line': 'true'}
				choice = select_dialog(slots, **kwargs)
				if choice is None: return
				execute_builtin('Addon.OpenSettings(%s)' % choice['module_id'])
				return
		data = settings.external_scraper_slot_data(slot)
		external = data['module']
		if external in ('empty_setting', ''): return
		execute_builtin('Addon.OpenSettings(%s)' % external)
	except: pass

def progress_dialog(heading='', icon=None):
	from threading import Thread
	from windows.base_window import create_window
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon or addon_icon())
	Thread(target=progress_dialog.run).start()
	for _ in range(40):
		try:
			if progress_dialog.getProperty('mando.progress_ready') == 'true':
				break
		except: pass
		sleep(50)
	return progress_dialog

def close_progress_dialog(progress):
	if not progress: return
	try:
		progress.is_canceled = True
		progress.close()
	except: pass

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

_DIALOG_CONFIRM_CHARS_PER_LINE = 42
_DIALOG_CONFIRM_VISIBLE_LINES = 5

def _dialog_needs_scroll(text):
	if not text: return False
	plain = text
	for tag in ('[B]', '[/B]', '[I]', '[/I]', '[COLOR yellow]', '[/COLOR]'):
		plain = plain.replace(tag, '')
	lines = [i.strip() for i in plain.split('[CR]') if i.strip()]
	wrapped = sum(max(1, (len(line) + _DIALOG_CONFIRM_CHARS_PER_LINE - 1) // _DIALOG_CONFIRM_CHARS_PER_LINE) for line in lines)
	return wrapped > _DIALOG_CONFIRM_VISIBLE_LINES

def confirm_dialog(heading='', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11, scroll=False, third_label=None):
	from windows.base_window import open_window
	needs_scroll = scroll and _dialog_needs_scroll(text)
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control,
				'third_label': third_label or '', 'scroll': 'true' if needs_scroll else 'false', 'scroll_focus': 'false'}
	raw = open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)
	if third_label:
		return raw
	if raw is True or raw is False:
		return raw
	return None

def ok_dialog(heading='', text='No Results', ok_label='OK', scroll=False):
	from windows.base_window import open_window
	needs_scroll = scroll and _dialog_needs_scroll(text)
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label,
				'scroll': 'true' if needs_scroll else 'false', 'scroll_focus': 'true' if needs_scroll else 'false'}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8') as r: text = r.readlines()
	if kodi_log:
		confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
		if confirm == None: return
		if confirm: text = [i for i in text if any(x in i.lower() for x in ('exception', 'error', '[test]'))]
	text = ''.join(text)
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

LIST_ITEM_NOT_IN_LIST = 'Item not in list'

def notification(line1, time=5000, icon=None, settle_ms=0):
	# Brief delay helps Kodi show the toast after select/confirm dialogs close (rapid calls can drop it otherwise).
	# sound=False: silent toast — especially during playback (Next Episode Ready, Next Up).
	if settle_ms: sleep(settle_ms)
	kodi_dialog().notification('Mando', line1, icon or addon_icon(), time, False)

def player_check(mode, params):
	from modules.settings import playback_key
	if mode == 'playback.%s' % playback_key():
		from modules.sources import Sources
		Sources().playback_prep(params)
	elif mode == 'playback.video':
		from modules.player import MandoPlayer
		MandoPlayer().run(params.get('url', None), params.get('obj', None))
	else: ok_dialog('External Playback Detected', 'Playback through external addons is not supported')

def external_playback_check(params):
	return True

def timeIt(func):
	# Thanks to 123Venom
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger('%s.%s' % (__name__ , fnc_name), (time.time() - started_at))
		return result
	return wrap

def volume_checker():
	# 0% == -60db, 100% == 0db
	try:
		if get_property('mando.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('mando.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index):
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: pass

def get_all_icons():
	import requests
	from caches.main_cache import cache_object
	username, location = media_github_credentials()
	def _process(dummy):
		try:
			results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/media/icons' % (username, location))
			results = [i['name'].replace('.png', '') for i in results.json()]
			return results
		except: return ['folder']
	return cache_object(_process, 'all_icons', 'foo', False, 168)

def get_all_addon_icons():
	import requests
	from caches.main_cache import cache_object
	username, location = media_github_credentials()
	def _process(dummy):
		try:
			results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/addon_icons' % (username, location))
			return results.json()
		except: return []
	return cache_object(_process, 'all_addon_icons', 'foo', True, 168)

def upload_logfile(params):
	import json
	import requests
	from modules.utils import copy2clip, make_qrcode
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file == None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	progressDialog = None
	url = 'https://paste.kodi.tv/'
	log_file = translate_path('special://logpath/%s' % log_file)
	if not path_exists(log_file): return ok_dialog(text='Error. Log Upload Failed')
	try:
		show_busy_dialog()
		try:
			with open_file(log_file) as f: text = f.read()
			UserAgent = 'script.kodi.loguploader: 1.0'
			response = requests.post('%s%s' % (url, 'documents'), data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent}).json()
		finally:
			hide_busy_dialog()
		if 'key' not in response:
			return ok_dialog(text='Error. Log Upload Failed')
		user_code = response['key']
		url = '%s%s' % (url, user_code)
		copy2clip(url)
		qr_code = make_qrcode(url) or ''
		progressDialog = progress_dialog(heading='Kodi Log Uploader', icon=qr_code)
		countdown_secs = 120
		remaining = countdown_secs
		while not progressDialog.iscanceled() and remaining > 0:
			progressDialog.update(
				'Share or Access with this url: [B]%s[/B][CR]Or scan the QR code on another device.[CR][CR]Auto-closes in [B]%d[/B] seconds (Back to dismiss now).' % (url, remaining),
				int(100 * remaining / countdown_secs))
			for _ in range(10):
				if progressDialog.iscanceled(): break
				sleep(100)
			remaining -= 1
	except:
		ok_dialog(text='Error. Log Upload Failed')
	finally:
		hide_busy_dialog()
		if progressDialog:
			try: progressDialog.close()
			except: pass

def fetch_kodi_imagecache(image):
	import sqlite3 as database
	result = None
	try:
		dbcon = database.connect(translate_path('special://database/Textures13.db'), timeout=40.0)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT cachedurl FROM texture WHERE url = ?", (image,))
		result = dbcur.fetchone()[0]
	except: pass
	return result
